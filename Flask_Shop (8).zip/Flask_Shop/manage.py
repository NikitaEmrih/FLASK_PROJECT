import shop

if __name__ == '__main__':
    shop.shop_app.run(debug = True)