from .app import admin

from .views import show_admin_page