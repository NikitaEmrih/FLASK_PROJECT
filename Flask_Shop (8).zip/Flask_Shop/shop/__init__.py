from .urls import *
from .settings import shop_app
from .login_manage import *
