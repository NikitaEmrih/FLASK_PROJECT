from .app import shop

from .views import show_shop_page