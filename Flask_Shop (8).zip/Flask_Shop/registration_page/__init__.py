from .app import registration_page
from .views import render