from .views import show_log_page
from .app import log_app